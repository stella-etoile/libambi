"""scripts/codec_compare.py: the quality search, the detail window, and a whole run on a small picture (policy partitioner, all outputs)."""
import csv
import importlib.util
import pathlib
import sys

import numpy as np
import pytest
from PIL import Image

SCRIPTS = pathlib.Path(__file__).resolve().parents[1] / "scripts"


def load_script():
    sys.path.insert(0, str(SCRIPTS))
    try:
        spec = importlib.util.spec_from_file_location("codec_compare", SCRIPTS / "codec_compare.py")
        mod = importlib.util.module_from_spec(spec)
        sys.modules["codec_compare"] = mod
        spec.loader.exec_module(mod)
        return mod
    finally:
        sys.path.pop(0)


cc = load_script()


def picture(h=64, w=64, seed=1):
    y, x = np.mgrid[0:h, 0:w]
    rng = np.random.default_rng(seed)
    rgb = np.stack([x * 4, y * 4, (x + y) * 2], -1) + rng.integers(0, 14, (h, w, 3))
    return np.clip(rgb, 0, 255).astype(np.uint8)


# ----------------------------------------------------------------------------------------- the search
def test_largest_ok_finds_the_boundary_and_uses_what_is_known():
    calls = []

    def ok(x):
        calls.append(x)
        return x <= 37

    assert cc.largest_ok(ok, 1, 100, []) == 37
    assert len(set(calls)) <= 8                                         # a bisection, not a scan
    calls.clear()
    assert cc.largest_ok(ok, 1, 100, [30, 40]) == 37
    assert len(set(calls)) <= 6                                         # the known points shrink the bracket first
    assert cc.largest_ok(lambda x: False, 1, 100, []) is None
    assert cc.largest_ok(lambda x: True, 1, 100, []) == 100


def test_match_by_size_takes_the_largest_quality_that_fits():
    codec = cc.PillowCodec("JPEG", "JPEG", ".jpg", picture(), (1, 95), dict(optimize=True))
    ref = codec.run(50)
    target = cc.Run("AMBI", 0.03, b"x" * (ref.bytes + 1), 0, 0, 0, 0, 0)
    r, ok = cc.match_codec(codec, "size", target)
    assert ok and r.bytes <= target.bytes and (r.param == 95 or codec.run(r.param + 1).bytes > target.bytes)


def test_match_by_psnr_takes_the_smallest_quality_that_reaches_it():
    codec = cc.PillowCodec("JPEG", "JPEG", ".jpg", picture(), (1, 95), dict(optimize=True))
    want = codec.run(60).psnr
    target = cc.Run("AMBI", 0.03, b"x", 0, want, 0, 0, 0)
    r, ok = cc.match_codec(codec, "psnr", target)
    assert ok and r.psnr >= want and (r.param == 1 or codec.run(r.param - 1).psnr < want)


def test_unreachable_targets_are_reported_not_hidden():
    codec = cc.PillowCodec("JPEG", "JPEG", ".jpg", picture(), (1, 95), dict(optimize=True))
    tiny = cc.Run("AMBI", 0.03, b"x" * 10, 0, 0, 0, 0, 0)               # smaller than any JPEG
    r, ok = cc.match_codec(codec, "size", tiny)
    assert not ok and r.param == 1
    high = cc.Run("AMBI", 0.03, b"x", 0, 999.0, 0, 0, 0)                # a PSNR no JPEG reaches
    r, ok = cc.match_codec(codec, "psnr", high)
    assert not ok and r.param == 95


def test_pillow_codec_measures_the_decoded_file():
    rgb = picture()
    codec = cc.PillowCodec("WebP", "WEBP", ".webp", rgb, (1, 100), dict(method=2))
    r = codec.run(70)
    dec = codec.decode(r)
    assert dec.shape == rgb.shape and r.psnr == pytest.approx(cc.psnr_rgb(rgb, dec)) and r.bpp == pytest.approx(r.bytes * 8 / (64 * 64))
    assert codec.run(70) is r                                           # cached


# ----------------------------------------------------------------------------------------- the detail window
def test_pick_box_is_inside_the_picture_and_repeatable():
    rgb = picture(80, 120)
    x, y, s = cc.pick_box(rgb, 48)
    assert s == 48 and 0 <= x <= 120 - 48 and 0 <= y <= 80 - 48
    assert cc.pick_box(rgb, 48) == (x, y, s)
    assert cc.pick_box(picture(20, 30), 96)[2] == 20                    # never larger than the picture


# ----------------------------------------------------------------------------------------- a whole run
@pytest.fixture(scope="module")
def tiny_setup(tmp_path_factory):
    torch = pytest.importorskip("torch")
    pytest.importorskip("matplotlib")
    from ambi_core import CodecConfig
    from ambi_core.profile import default_profile
    from ambi_rl.model import PolicyNet
    from ambi_rl.partitioner import save_policy
    d = tmp_path_factory.mktemp("cc")
    cfg = CodecConfig(tile=16, max_block=16, aspect_cap=4.0)
    prof = default_profile(cfg)
    prof.save(d / "tiny.ambiprofile")
    torch.manual_seed(0)
    save_policy(PolicyNet(cfg, width=16, hidden=32).eval(), d / "tiny.ambipolicy")
    Image.fromarray(picture(64, 64)).save(d / "pic.png")
    return d


def run_script(monkeypatch, d, out, *extra):
    argv = ["codec_compare.py", str(d / "pic.png"), "-o", str(out), "--profile", str(d / "tiny.ambiprofile"), "--policy", str(d / "tiny.ambipolicy"),
            "--prune-k", "2", "--workers", "1", "--device", "cpu", "--lams", "0.05", "0.3", "--qualities", "20", "60", "90", *extra]
    monkeypatch.setattr(sys, "argv", argv)
    assert cc.main() == 0


def test_whole_run_writes_both_pictures_the_files_and_the_csv(tiny_setup, monkeypatch, tmp_path, capsys):
    run_script(monkeypatch, tiny_setup, tmp_path, "--zoom-size", "32")
    for name in ("pic.rd_curves.png", "pic.comparison.png", "pic.telemetry.csv", "pic.jpg", "pic.webp", "pic.ambi"):
        assert (tmp_path / name).stat().st_size > 0, name
    for name in ("pic.rd_curves.png", "pic.comparison.png"):
        assert Image.open(tmp_path / name).size[0] > 800
    rows = list(csv.DictReader(open(tmp_path / "pic.telemetry.csv", encoding="utf-8")))
    ambi = [r for r in rows if r["codec"] == "AMBI"]
    assert {r["param"] for r in ambi} == {"0.05", "0.3", "0.03"}        # the sweep plus the compared lambda
    compared = [r for r in rows if r["compared"] == "1"]
    assert {r["codec"] for r in compared} >= {"JPEG", "WebP", "AMBI"} and len(compared) == len({r["codec"] for r in compared})
    # in the default mode each lossy codec's compared file is no larger than the AMBI one, unless even its lowest quality is bigger
    size = {r["codec"]: int(r["bytes"]) for r in compared}
    param = {r["codec"]: int(float(r["param"])) for r in compared}
    for name in ("JPEG", "WebP"):
        assert size[name] <= size["AMBI"] or param[name] == 1
    assert "matching each codec to AMBI's file size" in capsys.readouterr().out


def test_match_by_psnr_reaches_the_ambi_psnr(tiny_setup, monkeypatch, tmp_path):
    run_script(monkeypatch, tiny_setup, tmp_path, "--match", "psnr")
    rows = [r for r in csv.DictReader(open(tmp_path / "pic.telemetry.csv", encoding="utf-8")) if r["compared"] == "1"]
    psnr = {r["codec"]: float(r["psnr_rgb_db"]) for r in rows}
    for name in ("JPEG", "WebP"):
        assert psnr[name] >= psnr["AMBI"] - 1e-6 or int(next(r["param"] for r in rows if r["codec"] == name)) == (95 if name == "JPEG" else 100)


def test_runs_without_avif_and_says_so(tiny_setup, monkeypatch, tmp_path, capsys):
    monkeypatch.setattr(cc, "avif_problem", lambda: "no AVIF here")
    run_script(monkeypatch, tiny_setup, tmp_path)
    assert not (tmp_path / "pic.avif").exists() and (tmp_path / "pic.comparison.png").exists()
    assert "AVIF will be skipped: no AVIF here" in capsys.readouterr().out
    assert "AVIF" not in {r["codec"] for r in csv.DictReader(open(tmp_path / "pic.telemetry.csv", encoding="utf-8"))}


def test_crop_and_lossy_source_warning(tiny_setup, monkeypatch, tmp_path, capsys):
    Image.fromarray(picture(64, 64)).save(tiny_setup / "lossy.jpg", quality=90)
    monkeypatch.setattr(sys, "argv", ["codec_compare.py", str(tiny_setup / "lossy.jpg"), "-o", str(tmp_path), "--profile", str(tiny_setup / "tiny.ambiprofile"),
                                      "--policy", str(tiny_setup / "tiny.ambipolicy"), "--prune-k", "0", "--device", "cpu", "--lams", "0.1",
                                      "--qualities", "30", "80", "--crop", "32"])
    assert cc.main() == 0
    out = capsys.readouterr().out
    assert "already lossy" in out and "32x32" in out and "centre 32x32 crop" in out
    assert (tmp_path / "lossy.comparison.png").exists()
