import multiprocessing

if __name__ == "__main__":
    # the pruned search starts worker processes (spawn); a packaged .exe needs freeze_support, and the guard keeps a worker from
    # opening a second window when it re-imports this module
    multiprocessing.freeze_support()
    from .main import main
    raise SystemExit(main())
