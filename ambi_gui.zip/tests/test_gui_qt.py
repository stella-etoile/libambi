"""The AMBI window, driven offscreen: encode, open an .ambi, compare, cancel, and the controls that follow the Pruning choice."""
import os
import time

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import numpy as np
import pytest
from PIL import Image

pytest.importorskip("PySide6")
torch = pytest.importorskip("torch")
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication, QFileDialog, QMessageBox

from ambi_core import CodecConfig
from ambi_core.profile import default_profile
from ambi_gui.window import MainWindow

CFG = CodecConfig(tile=16, max_block=16, aspect_cap=4.0)


@pytest.fixture(scope="module")
def qapp():
    return QApplication.instance() or QApplication([])


@pytest.fixture()
def env(tmp_path, qapp, monkeypatch):
    from ambi_rl.model import PolicyNet
    from ambi_rl.partitioner import save_policy
    prof_dir, pol_dir = tmp_path / "profiles", tmp_path / "policies"
    prof_dir.mkdir(), pol_dir.mkdir()
    prof = default_profile(CFG)
    prof.name = "tiny-profile"
    prof.save(prof_dir / "tiny.ambiprofile")
    torch.manual_seed(0)
    save_policy(PolicyNet(CFG, width=16, hidden=32).eval(), pol_dir / "tiny.ambipolicy")
    y, x = np.mgrid[0:32, 0:32]
    rgb = np.clip(np.stack([x * 6, y * 6, (x + y) * 3], -1) + np.random.default_rng(1).integers(0, 12, (32, 32, 3)), 0, 255).astype(np.uint8)
    pic = tmp_path / "pic.png"
    Image.fromarray(rgb).save(pic)

    QSettings.setDefaultFormat(QSettings.Format.IniFormat)
    QSettings.setPath(QSettings.Format.IniFormat, QSettings.Scope.UserScope, str(tmp_path / "cfg"))
    qs = QSettings("AMBI", "ambi-gui")
    qs.clear()
    qs.setValue("profile_dir", str(prof_dir))
    qs.setValue("policy_dir", str(pol_dir))
    qs.setValue("workers", 1)
    qs.setValue("device_index", 1)             # CPU
    qs.setValue("last_dir", str(tmp_path))
    qs.sync()

    boxes = []
    monkeypatch.setattr(QMessageBox, "warning", lambda *a, **k: boxes.append(("warning", a[2])))
    monkeypatch.setattr(QMessageBox, "critical", lambda *a, **k: boxes.append(("critical", a[2])))
    win = MainWindow()
    win.show()
    qapp.processEvents()
    yield win, pic, rgb, tmp_path, boxes
    win.close()


def wait(app, win, timeout=120):
    t0 = time.time()
    while win.job is not None and time.time() - t0 < timeout:
        app.processEvents()
        time.sleep(0.005)
    app.processEvents()
    assert win.job is None, "the job did not finish"


def test_starts_empty_and_disabled(env):
    win, *_ = env
    assert not win.btn_encode.isEnabled() and not win.btn_save_ambi.isEnabled() and not win.btn_cancel.isEnabled()
    assert win.cmb_profile.currentText() == "tiny" and win.cmb_policy.currentText() == "tiny"
    assert win._k() == 5                                  # "k = 5 (recommended)" is the default


def test_encode_by_quality_then_save(env, qapp, monkeypatch):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    assert win.btn_encode.isEnabled() and win.view.mode() == "original"
    win.cmb_prune.setCurrentIndex(1)                      # k = 3
    win.sl_quality.setValue(50)
    win.encode()
    assert win.job is not None and not win.btn_encode.isEnabled() and win.btn_cancel.isEnabled()
    wait(qapp, win)
    o = win.outcome
    assert o is not None and not boxes and o.mode == "quality" and o.nbytes == len(win.ambi_data)
    assert win.view.mode() == "swipe" and win.view.has_both()
    assert "PSNR" in win.results.toPlainText() and "smaller" in win.results.toPlainText()
    assert win.btn_save_ambi.isEnabled() and win.btn_save_png.isEnabled()
    out = tmp / "saved.ambi"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(out), ""))
    win.save_ambi()
    assert out.read_bytes() == o.data
    png = tmp / "saved.png"
    monkeypatch.setattr(QFileDialog, "getSaveFileName", lambda *a, **k: (str(png), ""))
    win.save_png()
    assert np.array_equal(np.array(Image.open(png)), o.decoded)


def test_encode_by_file_size_uses_the_percentage_of_the_original(env, qapp):
    win, pic, *_ = env
    win.open_any(str(pic))
    win.rb_size.setChecked(True)
    win.cmb_unit.setCurrentIndex(2)
    win.sp_size.setValue(20.0)
    s = win._settings()
    assert s.mode == "size" and s.target_bytes == round(0.20 * pic.stat().st_size)
    win.cmb_unit.setCurrentIndex(0)
    win.sp_size.setValue(1.5)
    assert win._settings().target_bytes == 1536
    win.cmb_prune.setCurrentIndex(1)
    win.encode()
    wait(qapp, win)
    assert win.outcome is not None and win.outcome.mode == "size" and len(win.outcome.probes) >= 2


def test_open_an_ambi_decodes_and_compares_with_the_original(env, qapp, monkeypatch):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    win.cmb_prune.setCurrentIndex(1)
    win.encode()
    wait(qapp, win)
    made = win.outcome
    path = tmp / "made.ambi"
    path.write_bytes(made.data)

    win.open_any(str(path))                               # a fresh load of the file
    wait(qapp, win)
    assert not boxes and win.outcome is None and win.rgb is None
    assert np.array_equal(win.decoded, made.decoded) and win.view.mode() == "decoded"
    assert "tiny-profile" in win.results.toPlainText() and "no original" in win.results.toPlainText()
    assert win.btn_compare.isEnabled() and not win.btn_compare.isHidden()

    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(pic), ""))
    win.compare_with_original()
    wait(qapp, win)
    assert win.view.has_both() and "PSNR" in win.results.toPlainText()


def test_compare_refuses_a_picture_of_another_size(env, qapp, monkeypatch, tmp_path):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    win.cmb_prune.setCurrentIndex(1)
    win.encode()
    wait(qapp, win)
    path = tmp / "made.ambi"
    path.write_bytes(win.outcome.data)
    win.open_any(str(path))
    wait(qapp, win)
    other = tmp / "other.png"
    Image.fromarray(np.zeros((16, 16, 3), np.uint8)).save(other)
    monkeypatch.setattr(QFileDialog, "getOpenFileName", lambda *a, **k: (str(other), ""))
    win.compare_with_original()
    assert boxes and "cannot be compared" in boxes[-1][1]


def test_ambi_without_its_profile_shows_a_clear_message(env, qapp, tmp_path):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    win.cmb_prune.setCurrentIndex(1)
    win.encode()
    wait(qapp, win)
    path = tmp / "made.ambi"
    path.write_bytes(win.outcome.data)
    empty = tmp_path / "empty"
    empty.mkdir()
    win.profile_dir = str(empty)
    win._refresh_files()
    win.open_any(str(path))
    wait(qapp, win)
    assert boxes and boxes[-1][0] == "critical" and "no profile with id" in boxes[-1][1]
    assert win.job is None


def test_exact_oracle_turns_off_the_policy_and_worker_controls(env, qapp):
    win, *_ = env
    win.cmb_prune.setCurrentIndex(4)
    assert win._k() == -1
    assert not win.cmb_policy.isEnabled() and not win.sp_workers.isEnabled() and not win.cmb_device.isEnabled()
    win.cmb_prune.setCurrentIndex(0)                      # policy only: the policy matters, worker processes do not
    assert win.cmb_policy.isEnabled() and not win.sp_workers.isEnabled()
    win.cmb_prune.setCurrentIndex(2)
    assert win.sp_workers.isEnabled()


def test_no_policy_file_is_a_message_not_a_crash(env, qapp, tmp_path):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    win.policy_dir = str(tmp_path / "nowhere")
    win._refresh_files()
    win.encode()
    assert win.job is None and boxes and "policy" in boxes[-1][1]


def test_cancel_returns_the_window_to_idle(env, qapp):
    win, pic, rgb, tmp, boxes = env
    win.open_any(str(pic))
    win.cmb_prune.setCurrentIndex(1)
    win.rb_size.setChecked(True)
    win.cmb_unit.setCurrentIndex(0)
    win.sp_size.setValue(0.2)                             # unreachable: the search would run all its probes
    win.encode()
    qapp.processEvents()
    win.cancel()
    wait(qapp, win)
    assert win.outcome is None and not boxes and win.btn_encode.isEnabled() and win.lbl_status.text() == "Cancelled."
    win.rb_quality.setChecked(True)
    win.encode()                                          # and the window still encodes afterwards
    wait(qapp, win)
    assert win.outcome is not None


def test_settings_are_remembered(env, qapp, tmp_path):
    win, pic, rgb, tmp, boxes = env
    win.sl_quality.setValue(33)
    win.cmb_prune.setCurrentIndex(3)
    win.rb_psnr.setChecked(True)
    win.sp_psnr.setValue(31.5)
    win._save_settings()
    again = MainWindow()
    try:
        assert again.sl_quality.value() == 33 and again.cmb_prune.currentIndex() == 3
        assert again.rb_psnr.isChecked() and again.sp_psnr.value() == pytest.approx(31.5)
        assert again.cmb_profile.currentText() == "tiny"
    finally:
        again.engine.close()
        again.close()
