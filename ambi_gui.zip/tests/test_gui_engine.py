"""The GUI's engine (no Qt): quality/size/PSNR encodes, the λ search, cancel, and finding the profile that decodes a file."""
import threading
import time

import numpy as np
import pytest

from ambi_core import CodecConfig
from ambi_core.bitstream import decode_image
from ambi_core.entropy import EntropyModel
from ambi_core.profile import Profile, default_profile
from ambi_gui.engine import (LAM_MAX, LAM_MIN, Cancelled, EncodeSettings, Engine, EngineError, jpeg_at_psnr, lam_to_quality,
                             png_size, quality_to_lam, solve_lambda)

CFG = CodecConfig(tile=16, max_block=16, aspect_cap=4.0)


@pytest.fixture(scope="module")
def world(tmp_path_factory):
    torch = pytest.importorskip("torch")
    from ambi_rl.model import PolicyNet
    from ambi_rl.partitioner import save_policy
    d = tmp_path_factory.mktemp("gui")
    prof = default_profile(CFG)
    prof.name = "tiny-profile"
    prof.save(d / "tiny.ambiprofile")
    torch.manual_seed(0)
    save_policy(PolicyNet(CFG, width=16, hidden=32).eval(), d / "tiny.ambipolicy")
    rng = np.random.default_rng(1)
    y, x = np.mgrid[0:32, 0:32]
    rgb = np.stack([x * 6, y * 6, (x + y) * 3], -1) + rng.integers(0, 12, (32, 32, 3))
    rgb = np.clip(rgb, 0, 255).astype(np.uint8)
    eng = Engine()
    yield d, rgb, eng
    eng.close()


def settings(d, **kw):
    base = dict(profile_path=str(d / "tiny.ambiprofile"), policy_path=str(d / "tiny.ambipolicy"), prune_k=2, workers=1, device="cpu",
                compare=False)
    base.update(kw)
    return EncodeSettings(**base)


# --------------------------------------------------------------------------------------- helpers
def test_quality_and_lambda_round_trip():
    # λ weighs bits in the cost J = distortion + λ·bits: a large λ means a small file, so quality 0 is the largest λ
    assert quality_to_lam(0) == pytest.approx(LAM_MAX)
    assert quality_to_lam(100) == pytest.approx(LAM_MIN)
    for q in (0, 10, 50, 90, 100):
        assert lam_to_quality(quality_to_lam(q)) == pytest.approx(q, abs=1e-6)
    assert quality_to_lam(30) > quality_to_lam(70)


def test_png_and_jpeg_references(world):
    _, rgb, _ = world
    assert png_size(rgb) > 0
    r = jpeg_at_psnr(rgb, 30.0)
    assert r["reached"] and r["psnr"] >= 30.0 and r["bytes"] > 0
    assert not jpeg_at_psnr(rgb, 99.0)["reached"]


# --------------------------------------------------------------------------------------- the λ solver
def test_solve_lambda_finds_a_size_target():
    # a smooth made-up curve: bytes fall as λ grows
    f = lambda lam: 1000.0 * (0.03 / lam) ** 0.4
    probes, best, reached = solve_lambda(f, "size", 700.0)
    assert reached and len(probes) <= 7
    assert 0.97 * 700 <= probes[best][1] <= 700


def test_solve_lambda_reports_an_unreachable_target():
    f = lambda lam: 5000.0                                  # no λ changes anything
    probes, best, reached = solve_lambda(f, "size", 100.0)
    assert not reached and len(probes) <= 7


# --------------------------------------------------------------------------------------- encodes
def test_quality_encode_decodes_to_what_it_reports(world):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    assert o.mode == "quality" and o.reached
    prof = eng.profile(d / "tiny.ambiprofile")
    assert np.array_equal(o.decoded, decode_image(o.data, prof))
    assert o.nbytes == len(o.data) and o.psnr > 20
    assert o.prune is not None and o.prune["k"] == 2 and 0 < o.prune["looked"] <= 100


def test_a_larger_lambda_is_a_smaller_and_worse_file(world):
    d, rgb, eng = world
    fine = eng.encode(rgb, settings(d, mode="quality", lam=0.01))
    coarse = eng.encode(rgb, settings(d, mode="quality", lam=0.3))
    assert coarse.nbytes < fine.nbytes and coarse.psnr < fine.psnr


def test_policy_only_has_no_prune_stats(world):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, prune_k=0, mode="quality", lam=0.05))
    assert o.prune is None


def test_size_target_with_the_policy(world):
    d, rgb, eng = world
    ref = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    target = int(ref.nbytes * 0.85)
    o = eng.encode(rgb, settings(d, mode="size", target_bytes=target))
    assert len(o.probes) >= 2
    if o.reached:
        assert o.nbytes <= target
    else:
        assert "over" in o.message


def test_psnr_target_with_the_policy(world):
    d, rgb, eng = world
    ref = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    o = eng.encode(rgb, settings(d, mode="psnr", target_psnr=ref.psnr - 1.0))
    if o.reached:
        assert o.psnr >= ref.psnr - 1.0 - 1e-6
    else:
        assert "could not reach" in o.message


def test_oracle_needs_no_policy(world):
    d, rgb, eng = world
    o = eng.encode(rgb, EncodeSettings(profile_path=str(d / "tiny.ambiprofile"), prune_k=-1, mode="quality", lam=0.05, compare=False))
    assert o.prune is None and o.nbytes > 0
    pruned = eng.encode(rgb, settings(d, prune_k=2, mode="quality", lam=0.05))
    assert o.nbytes <= pruned.nbytes * 1.001                # the exact search is never worse than the pruned one on its own cost


def test_compare_with_png_and_jpeg(world):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05, compare=True), original_file_bytes=12345)
    assert o.png_bytes and o.jpeg is not None and o.original_file_bytes == 12345


def test_missing_policy_is_a_clear_error(world):
    d, rgb, eng = world
    with pytest.raises(EngineError, match="policy"):
        eng.encode(rgb, settings(d, policy_path=str(d / "nope.ambipolicy")))


def test_cancel_stops_a_search_and_the_engine_still_works(world):
    d, rgb, eng = world
    cancel = threading.Event()
    seen = []

    def on_progress(text, frac):
        seen.append(text)
        cancel.set()                                         # cancel as soon as anything is reported

    with pytest.raises(Cancelled):
        eng.encode(rgb, settings(d, mode="size", target_bytes=200), on_progress=on_progress, cancel=cancel)
    assert seen
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    assert o.nbytes > 0


# --------------------------------------------------------------------------------------- decoding
def test_decode_finds_the_profile_by_id_and_fingerprint(world):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    out = eng.decode(o.data, [str(d)])
    assert np.array_equal(out.rgb, o.decoded) and out.profile_name == "tiny-profile"
    assert out.info["width"] == 32 and out.info["total_bytes"] == len(o.data)


def test_decode_refuses_a_profile_with_the_same_id_but_other_tables(world, tmp_path):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    other = Profile("imposter", 0, CodecConfig(tile=16, max_block=16, aspect_cap=2.0), EntropyModel(CodecConfig(tile=16, max_block=16, aspect_cap=2.0)))
    other.save(tmp_path / "imposter.ambiprofile")
    with pytest.raises(EngineError, match="different tables"):
        eng.decode(o.data, [str(tmp_path)])


def test_decode_with_no_profile_folder_says_what_is_missing(world, tmp_path):
    d, rgb, eng = world
    o = eng.encode(rgb, settings(d, mode="quality", lam=0.05))
    with pytest.raises(EngineError, match="no profile with id"):
        eng.decode(o.data, [str(tmp_path)])
